#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $ModuleDir if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}
# This script will be executed in post-fs-data mode

# 内部脚本路径
InternalSh="$MODDIR/internal/internal.sh"

# 监听线程运行情况下关机或重启，则残留标志位文件从而影响一些功能，因此开机脚本中加入标志位清理与转换
# 以下列出所有标志位在此脚本对应的处理，已省去路径
# --拷贝内部脚本全局变量过来，发布时注释，编写时取消注释用于代码提示--

# 模块安装路径
ModuleDir=MODULE_DIR
# 使用的busybox路径
BusyBox=BUSY_BOX
# 王者包名
Package=SGAME_PACKAGE
# 王者本地配置文件目录
SharedPrefs=SGAME_SHAREDPREFS
# 王者优化参数配置文件
File=SGAME_FILE

# 模块配置文件
ModuleProp=MODULE_PROP
# 内部标志位目录
InternalFlagDir=INTERNAL_FLAG_DIR
# 倒计时配置文件
TimerConf=TIMER_CONF
# 日志配置文件
LogConf=LOG_CONF
# 日志文件
LogFile=LOG_FILE

# 可用模式
ModeOpenGLES3="OpenGLES3"
ModeVulkan="Vulkan"
ModeVisitor="Visitor"

# 以下是标志位前缀---
# 王者标志位前缀
SgameFlagPrefix="王者"  # --删除--
# 监听线程标志位前缀
MonitorFlagPrefix="监听线程"  # --删除--
# 当前优化标志位前缀
CurrentOptimizeFlagPrefix="当前优化"  # --删除--
# 当前模式标志位前缀
CurrentModeFlagPrefix="当前模式"  # --保留--则可使用最后一次用过的模式作为开始模式
# 切换模式标志位前缀，内部
ChangeModeFlagPrefix="切换模式"  # --删除并转换--
# 倒计时标志位前缀
TimerFlagPrefix="倒计时"  # --删除--

# 以下是固定标志位---
# 切换模式标志位，内部
FlagChangeModeOpenGLES3="$InternalFlagDir/切换模式${ModeOpenGLES3}"  # --删除并转换--关机或重启没来得及切换，转换成对应的当前模式标志位
FlagChangeModeVulkan="$InternalFlagDir/切换模式${ModeVulkan}"  # --删除并转换--
FlagChangeModeVisitor="$InternalFlagDir/切换模式${ModeVisitor}"  # --删除并转换--
# 关闭监听线程标志位，内部
FlagCloseMonitor="$InternalFlagDir/关闭监听线程"  # --删除--防止一启动监听线程就立即关闭
# 倒计时关闭监听线程标志位，内部
FlagTimerCloseMonitor="$InternalFlagDir/倒计时关闭监听线程"  # --保留--以便输出倒计时数据至倒计时配置及日志
# 已启用倒计时标志位，内部
FlagTimerApplied="$InternalFlagDir/已启用倒计时"  # --删除并转换--转换成已暂停倒计时标志位，以便继续完成倒计时
# 启用倒计时标志位，内部
FlagApplyTimer="$InternalFlagDir/启用倒计时"  # --删除--关机或重启没来得及启用，那就手动再启用一次
# 暂停计时标志位，内部
FlagPauseTimer="$InternalFlagDir/暂停倒计时"  # --删除并转换--转换成已暂停倒计时标志位，以便继续完成倒计时
# 关闭倒计时标志位，内部
FlagCloseTimer="$InternalFlagDir/关闭倒计时"  # --删除并做相应处理--关机或重启已经关闭了倒计时，但没有做关闭倒计时的处理，即重置倒计时内部配置及清空外部倒计时配置的数据显示
# 已暂停倒计时标志位
FlagTimerPaused="$ModuleDir/已暂停倒计时"  # --保留--以便继续完成倒计时
# 已启用模式标志位
FlagOpenGLES3Applied="$ModuleDir/已启用${ModeOpenGLES3}模式"  # --删除--否则无法切换模式，关机或重启模式已经停止
FlagVulkanApplied="$ModuleDir/已启用${ModeVulkan}模式"    # --删除--
FlagVisitorApplied="$ModuleDir/已启用${ModeVisitor}模式"  # --删除--
# 停用模式标志位，内部
FlagStopOpenGLES3="$InternalFlagDir/停用${ModeOpenGLES3}模式"  # --删除--防止一启动游戏就停用模式
FlagStopVulkan="$InternalFlagDir/停用${ModeVulkan}模式"  # --删除--
FlagStopVisitor="$InternalFlagDir/停用${ModeVisitor}模式"  # --删除--
# 当前模式标志位
FlagCurrentModeOpenGLES3="$ModuleDir/当前模式${ModeOpenGLES3}"  # --保留--则可使用最后一次用过的模式作为开始模式
FlagCurrentModeVulkan="$ModuleDir/当前模式${ModeVulkan}"  # --保留--
FlagCurrentModeVisitor="$ModuleDir/当前模式${ModeVisitor}"  # --保留--
# 王者已关闭标志位
FlagSgameClosed="$ModuleDir/王者已关闭"  # --删除--通过前缀删除
# 监听线程运行中标志位
FlagMonitorRunning="$ModuleDir/监听线程运行中"  # --删除--通过前缀删除，否则无法启动监听线程，关机或重启监听线程已停止
# 启用自启标志位
FlagEnableBoot="$ModuleDir/已启用自启"  # --保留--用于判断是否启用监听线程开机自启

# 以下是模块列表各项目显示可用状态
# 王者荣耀
StateSgameDefault="未监听"
StateSgameClosed="已关闭"
StateSgameRunning="运行中"
# 监听线程
StateMonitorClosed="已关闭"
StateMonitorRunning="运行中"
# 当前优化
StateCurrentOptimizeDefault="模式未启用"
# 当前模式显示后缀
StateCurrentModeClosedSuffix="（未启用）"
StateCurrentModeRunningSuffix="（已启用）"
# 当前模式
StateCurrentModeDefault="$ModeOpenGLES3$StateCurrentModeClosedSuffix"
# 倒计时
StateTimerClosed="已关闭"
# 倒计时已暂停后缀
StateTimerPausedSuffix="（已暂停）"


# 因关机或重启切换模式没来得及，在此转换，显然同时切换多个模式优先级别高到低顺序是OpenGLES3，Vulkan ，Visitor
convertChangeModeFlag(){
  # 同时切换当前模式外的另外多个模式，显然这里优先级别高到低顺序是OpenGLES3，Vulkan,Visitor
  if [ -f $FlagChangeModeOpenGLES3 ]; then
    # 删除切换模式标志位
    removeInternalFlag $ChangeModeFlagPrefix
    # 转换成当前模式标志位
    createModuleFlag $CurrentModeFlagPrefix $ModeOpenGLES3
    # 刷新模块列表当前模式显示未启用
    refreshCurrentModeDisplay "$ModeOpenGLES3$StateCurrentModeClosedSuffix"
  elif [ -f $FlagChangeModeVulkan ]; then
    # 删除切换模式标志位
    removeInternalFlag $ChangeModeFlagPrefix
    # 转换成当前模式标志位
    createModuleFlag $CurrentModeFlagPrefix $ModeVulkan
    # 刷新模块列表当前模式显示未启用
    refreshCurrentModeDisplay "$ModeVulkan$StateCurrentModeClosedSuffix"
  elif [ -f $FlagChangeModeVisitor ]; then
    # 删除切换模式标志位
    removeInternalFlag $ChangeModeFlagPrefix
    # 转换成当前模式标志位
    createModuleFlag $CurrentModeFlagPrefix $ModeVisitor
    # 刷新模块列表当前模式显示未启用
    refreshCurrentModeDisplay "$ModeVisitor$StateCurrentModeClosedSuffix"
  fi
}
# 若存在当前模式标志位则显示未启用，否则显示默认模式状态
checkCurrentModeFlagAndRefreshDisplay(){
  if [ -f $FlagCurrentModeOpenGLES3 ]; then
    # 刷新模块列表当前模式显示OpenGLES3未启用
    refreshCurrentModeDisplay "$ModeOpenGLES3$StateCurrentModeClosedSuffix"
    return
  elif [ -f $FlagCurrentModeVulkan ]; then
    # 刷新模块列表当前模式显示Vulkan未启用
    refreshCurrentModeDisplay "$ModeVulkan$StateCurrentModeClosedSuffix"
    return
  elif [ -f $FlagCurrentModeVisitor ]; then
    # 刷新模块列表当前模式显示Visitor未启用
    refreshCurrentModeDisplay "$ModeVisitor$StateCurrentModeClosedSuffix"
    return
  fi
  # 刷新模块列表当前模式显示默认模式状态
  refreshCurrentModeDisplay "$StateCurrentModeDefault"
}
# 倒计时相关标志位的删除与转换
convertRelatedTimerFlag(){
  # 删除并转换已启用倒计时标志位
  if [ -f $FlagTimerApplied ]; then
    # 删除已启用倒计时标志位
    rm -rf $FlagTimerApplied
    # 创建已暂停倒计时标志位
    createConstantFlag $FlagTimerPaused
    # 获取倒计时剩余时间
    local RemainTime=`grep_prop "RemainTime" $TimerConf`
    # 模块列表倒计时显示剩余时间及已暂停状态
    refreshTimerDisplay "$RemainTime$StateTimerPausedSuffix"
    # 输出日志
    outputLog "--因关机或重启，已启用倒计时处理为已暂停倒计时--"
  fi
  # 删除启用倒计时标志位
  removeConstantFlag $FlagApplyTimer
  # 删除并转换暂停倒计时标志位
  if [ -f $FlagPauseTimer ]; then
    # 删除暂停倒计时标志位
    rm -rf $FlagPauseTimer
    # 创建已暂停倒计时标志位
    createConstantFlag $FlagTimerPaused
    # 获取倒计时剩余时间
    local RemainTime=`grep_prop "RemainTime" $TimerConf`
    # 模块列表倒计时显示剩余时间且及暂停状态
    refreshTimerDisplay "$RemainTime$StateTimerPausedSuffix"
    # 输出日志
    outputLog "--因关机或重启未能及时暂停倒计时，已处理为已暂停倒计时--"
  fi
  # 删除关闭倒计时标志位，清空倒计时配置
  if [ -f $FlagCloseTimer ]; then
    # 清空倒计时配置
    clearTimerConf
    # 模块列表倒计时显示已关闭
    refreshTimerDisplay "$StateTimerClosed"
    # 输出日志
    outputLog "--因关机或重启未能及时关闭倒计时，已执行关闭倒计时相应操作--"
  fi
}
# 删除与转换监听线程未关闭情况下关机或重启而残留的标志位文件
controlFlag(){
  # 删除前缀标志位文件，包含王者、监听线程、当前优化、倒计时，保留当前模式标志位，用于监听线程的开始模式
  removeModuleFlags $SgameFlagPrefix $MonitorFlagPrefix $CurrentOptimizeFlagPrefix $TimerFlagPrefix
  # 删除关闭监听线程标志位
  removeConstantFlag $FlagCloseMonitor
  # 删除已启用模式标志位
  removeConstantFlags $FlagOpenGLES3Applied $FlagVulkanApplied $FlagVisitorApplied
  # 删除停用模式标志位
  removeConstantFlags $FlagStopOpenGLES3 $FlagStopVulkan $FlagStopVulkan
  # 模块列表王者显示默认值
  refreshSgameDisplay $StateSgameDefault
  # 模块列表监听线程显示已关闭
  refreshMonitorDisplay $StateMonitorClosed
  # 模块列表当前优化显示默认值
  refreshCurrentOptimizeDisplay $StateCurrentOptimizeDefault
  # 删除与转换切换模式标志位
  convertChangeModeFlag
  # 若存在当前模式标志位则显示未启用，否则显示默认模式状态
  checkCurrentModeFlagAndRefreshDisplay
  # 模块列表倒计时显示已关闭
  refreshTimerDisplay $StateTimerClosed
  # 删除与转换倒计时相关标志位
  convertRelatedTimerFlag
}

if [ -f $InternalSh ]; then
  # 加载内部脚本
  . $InternalSh
  # 检查所有配置有效性
  checkAllConf
  # 删除与转换监听线程未关闭情况下关机或重启而导致残留的标志位文件
  # 注意，并非是启用自启后才需要清除残留标志位，且必须在开机自启监听线程之前操作，否则残留标志位会影响自启监听线程
  controlFlag
  # 监听线程开机自启判断
  if [[ -f $FlagEnableBoot && -f $MODDIR/启动监听线程.sh ]]; then
    # 执行启动监听线程脚本
    sh $MODDIR/启动监听线程.sh
    [ $? -eq 0 ] && outputLog "--监听线程开机自启成功--" || outputLog "--监听线程开机自启失败--"
  fi
else
  echo "--内部脚本缺失！开机脚本无法进行操作！--" >> $MODDIR/日志.txt
fi

