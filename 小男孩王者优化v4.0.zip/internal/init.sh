#!/system/bin/sh
# 此脚本需在安装脚本中加载调用
initFiles(){
  # 模块功能目录名称
  DirTimer="定时关闭"
  DirChangeMode="切换模式"
  DirLogOperation="日志操作"
  DirBootSetting="自启设定"
  DirClearSgame="清空王者"
  DirModuleUpdate="模块更新"
  DirInternal="internal"
  DirInternalFlag="internal_flag"
  # 模块脚本及配置文件名
  ShChangeModeOpenGLES3="切换至OpenGLES3模式.sh"
  ShChangeModeVulkan="切换至Vulkan模式.sh"
  ShChangeModeVisitor="切换至Visitor模式.sh"
  ShRunMonitor="启动监听线程.sh"
  ShStopMonitor="关闭监听线程.sh"
  ShDeleteLog="删除日志.sh"
  ShClearSgame="清空王者本地配置.sh"
  ShRunTimer="启用倒计时.sh"
  ShStopTimer="关闭倒计时.sh"
  ShEnableBoot="启用开机自启.sh"
  ShDisableBoot="关闭开机自启.sh"
  ShInternal="internal.sh"
  ShInit="init.sh"
  ShCheckUpdate="检查更新.sh"
  TimerConf="倒计时配置.conf"
  LogConf="日志配置.conf"
  LogFile="日志.txt"

  # 模块目录创建
  # internal及其子目录
  mkdir -p $MODPATH/$DirInternal/$DirInternalFlag
  # 定时关闭目录
  mkdir -p $MODPATH/$DirTimer
  # 切换目录
  mkdir -p $MODPATH/$DirChangeMode
  # 清空王者目录
  mkdir -p $MODPATH/$DirClearSgame
  # 日志操作目录
  mkdir -p $MODPATH/$DirLogOperation
  # 自启设定目录
  mkdir -p $MODPATH/$DirBootSetting
  # 模块更新目录
  mkdir -p $MODPATH/$DirModuleUpdate

  # 只拷贝临时目录下的必要文件至模块安装目录（非模块安装完成后的目录，这里应是模块更新目录）
  # 从临时目录的子目录拷贝文件（有后缀名的）至模块安装目录的对应子目录
  cp -af $TMPDIR/$DirInternal/*.* $MODPATH/$DirInternal
  cp -af $TMPDIR/$DirTimer/*.* $MODPATH/$DirTimer
  cp -af $TMPDIR/$DirChangeMode/*.* $MODPATH/$DirChangeMode
  cp -af $TMPDIR/$DirClearSgame/*.* $MODPATH/$DirClearSgame
  cp -af $TMPDIR/$DirLogOperation/*.* $MODPATH/$DirLogOperation
  cp -af $TMPDIR/$DirBootSetting/*.* $MODPATH/$DirBootSetting
  cp -af $TMPDIR/$DirModuleUpdate/*.* $MODPATH/$DirModuleUpdate
  # 从临时目录拷贝文件至模块安装目录
  cp -af $TMPDIR/$ShRunMonitor $MODPATH/$ShRunMonitor
  cp -af $TMPDIR/$ShStopMonitor $MODPATH/$ShStopMonitor
}
initShAndFiles(){
  # 初始化文件
  initFiles
  # 模块安装完成后的路径，参数1
  local ModuleDir=$1
  # 传入用于初始化的busybox，参数2
  local BusyBox=$2

  # 内部脚本路径，非安装完成后路径
  local internalSh=$MODPATH/$DirInternal/$ShInternal

  # 王者包名
  local package="com.tencent.tmgp.sgame"
  # 王者本地配置文件目录
  local sharedPrefs="/data/data/${package}/shared_prefs"
  # 王者优化参数配置文件
  local file="${sharedPrefs}/com.tencent.tmgp.sgame.v2.playerprefs.xml"

  # 写入模块安装完成后的路径到内部脚本
  $BusyBox sed -i "s:MODULE_DIR:$ModuleDir:" $internalSh
  # 写入busybox路径到内部脚本
  $BusyBox sed -i "s:BUSY_BOX:$BusyBox:" $internalSh
  # 写入王者包名、本地配置目录、优化参数文件路径到内部脚本
  $BusyBox sed -i "s:SGAME_PACKAGE:$package:" $internalSh
  $BusyBox sed -i "s:SGAME_SHAREDPREFS:$sharedPrefs:" $internalSh
  $BusyBox sed -i "s:SGAME_FILE:$file:" $internalSh

  # 写入王者本地配置目录至清空王者本地配置脚本
  $BusyBox sed -i "s:SGAME_SHAREDPREFS:$sharedPrefs:" $MODPATH/$DirClearSgame/$ShClearSgame

  # 以下路径配置基于模块安装完成后的路径
  # 模块配置文件
  local moduleProp="$ModuleDir/module.prop"
  # 模块更新目录
  local moduleUpdateDir="$ModuleDir/$DirModuleUpdate"
  # 内部目录
  local internalDir="$ModuleDir/$DirInternal"
  # 内部标志位目录
  local internalFlagDir="$ModuleDir/$DirInternal/$DirInternalFlag"
  # 倒计时配置文件
  local timerConf="$ModuleDir/$DirTimer/$TimerConf"
  # 日志配置文件
  local logConf="$ModuleDir/$DirLogOperation/$LogConf"
  # 日志文件
  local logFile="$ModuleDir/$LogFile"
  # 写入上面路径至内部脚本
  $BusyBox sed -i "s:MODULE_PROP:$moduleProp:" $internalSh
  $BusyBox sed -i "s:MODULE_UPDATE_DIR:$moduleUpdateDir:" $internalSh
  $BusyBox sed -i "s:INTERNAL_DIR:$internalDir:" $internalSh
  $BusyBox sed -i "s:INTERNAL_FLAG_DIR:$internalFlagDir:" $internalSh
  $BusyBox sed -i "s:TIMER_CONF:$timerConf:" $internalSh
  $BusyBox sed -i "s:LOG_CONF:$logConf:" $internalSh
  $BusyBox sed -i "s:LOG_FILE:$logFile:" $internalSh

  # ---赋值模块安装完成后的内部脚本路径---
  internalSh=$ModuleDir/$DirInternal/$ShInternal
  # 写入模块安装完成后的内部脚本路径到其它脚本
  $BusyBox sed -i "s:INTERNAL_SH:$internalSh:" $MODPATH/$ShRunMonitor
  $BusyBox sed -i "s:INTERNAL_SH:$internalSh:" $MODPATH/$ShStopMonitor
  $BusyBox sed -i "s:INTERNAL_SH:$internalSh:" $MODPATH/$DirChangeMode/$ShChangeModeOpenGLES3
  $BusyBox sed -i "s:INTERNAL_SH:$internalSh:" $MODPATH/$DirChangeMode/$ShChangeModeVulkan
  $BusyBox sed -i "s:INTERNAL_SH:$internalSh:" $MODPATH/$DirChangeMode/$ShChangeModeVisitor
  $BusyBox sed -i "s:INTERNAL_SH:$internalSh:" $MODPATH/$DirLogOperation/$ShDeleteLog
  $BusyBox sed -i "s:INTERNAL_SH:$internalSh:" $MODPATH/$DirTimer/$ShRunTimer
  $BusyBox sed -i "s:INTERNAL_SH:$internalSh:" $MODPATH/$DirTimer/$ShStopTimer
  $BusyBox sed -i "s:INTERNAL_SH:$internalSh:" $MODPATH/$DirBootSetting/$ShEnableBoot
  $BusyBox sed -i "s:INTERNAL_SH:$internalSh:" $MODPATH/$DirBootSetting/$ShDisableBoot
  $BusyBox sed -i "s:INTERNAL_SH:$internalSh:" $MODPATH/$DirModuleUpdate/$ShCheckUpdate
}