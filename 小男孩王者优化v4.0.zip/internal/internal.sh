#!/system/bin/sh
# 模块安装路径
ModuleDir=MODULE_DIR
# 使用的busybox路径
BusyBox=BUSY_BOX
# 王者包名
Package=SGAME_PACKAGE
# 王者本地配置文件目录
SharedPrefs=SGAME_SHAREDPREFS
# 王者优化参数配置文件
File=SGAME_FILE

# 模块配置文件
ModuleProp=MODULE_PROP
# 模块更新目录
ModuleUpdateDir=MODULE_UPDATE_DIR
# 内部目录
InternalDir=INTERNAL_DIR
# 内部标志位目录
InternalFlagDir=INTERNAL_FLAG_DIR
# 倒计时配置文件
TimerConf=TIMER_CONF
# 日志配置文件
LogConf=LOG_CONF
# 日志文件
LogFile=LOG_FILE

# 可用模式
ModeOpenGLES3="OpenGLES3"
ModeVulkan="Vulkan"
ModeVisitor="Visitor"

# 以下是标志位前缀---
# 王者标志位前缀
SgameFlagPrefix="王者"
# 监听线程标志位前缀
MonitorFlagPrefix="监听线程"
# 当前优化标志位前缀
CurrentOptimizeFlagPrefix="当前优化"
# 当前模式标志位前缀
CurrentModeFlagPrefix="当前模式"
# 切换模式标志位前缀，内部
ChangeModeFlagPrefix="切换模式"
# 倒计时标志位前缀
TimerFlagPrefix="倒计时"

# 以下是固定标志位---
# 切换模式标志位，内部
FlagChangeModeOpenGLES3="$InternalFlagDir/切换模式${ModeOpenGLES3}"
FlagChangeModeVulkan="$InternalFlagDir/切换模式${ModeVulkan}"
FlagChangeModeVisitor="$InternalFlagDir/切换模式${ModeVisitor}"
# 关闭监听线程标志位，内部
FlagCloseMonitor="$InternalFlagDir/关闭监听线程"
# 倒计时关闭监听线程标志位，内部
FlagTimerCloseMonitor="$InternalFlagDir/倒计时关闭监听线程"
# 已启用倒计时标志位，内部
FlagTimerApplied="$InternalFlagDir/已启用倒计时"
# 启用倒计时标志位，内部
FlagApplyTimer="$InternalFlagDir/启用倒计时"
# 暂停计时标志位，内部
FlagPauseTimer="$InternalFlagDir/暂停倒计时"
# 关闭倒计时标志位，内部
FlagCloseTimer="$InternalFlagDir/关闭倒计时"
# 已暂停倒计时标志位
FlagTimerPaused="$ModuleDir/已暂停倒计时"
# 已启用模式标志位
FlagOpenGLES3Applied="$ModuleDir/已启用${ModeOpenGLES3}模式"
FlagVulkanApplied="$ModuleDir/已启用${ModeVulkan}模式"
FlagVisitorApplied="$ModuleDir/已启用${ModeVisitor}模式"
# 停用模式标志位，内部
FlagStopOpenGLES3="$InternalFlagDir/停用${ModeOpenGLES3}模式"
FlagStopVulkan="$InternalFlagDir/停用${ModeVulkan}模式"
FlagStopVisitor="$InternalFlagDir/停用${ModeVisitor}模式"
# 当前模式标志位
FlagCurrentModeOpenGLES3="$ModuleDir/当前模式${ModeOpenGLES3}"
FlagCurrentModeVulkan="$ModuleDir/当前模式${ModeVulkan}"
FlagCurrentModeVisitor="$ModuleDir/当前模式${ModeVisitor}"
# 王者已关闭标志位
FlagSgameClosed="$ModuleDir/王者已关闭"
# 监听线程运行中标志位
FlagMonitorRunning="$ModuleDir/监听线程运行中"
# 启用自启标志位
FlagEnableBoot="$ModuleDir/已启用自启"

# 以下是模块列表各项目显示可用状态
# 王者荣耀
StateSgameDefault="未监听"
StateSgameClosed="已关闭"
StateSgameRunning="运行中"
# 监听线程
StateMonitorClosed="已关闭"
StateMonitorRunning="运行中"
# 当前优化
StateCurrentOptimizeDefault="模式未启用"
# 当前模式显示后缀
StateCurrentModeClosedSuffix="（未启用）"
StateCurrentModeRunningSuffix="（已启用）"
# 当前模式
StateCurrentModeDefault="$ModeOpenGLES3$StateCurrentModeClosedSuffix"
# 倒计时
StateTimerClosed="已关闭"
# 倒计时已暂停后缀
StateTimerPausedSuffix="（已暂停）"

# 日志输出方法
outputLog(){
  # $1日志内容
  echo "$($BusyBox date +%y-%m-%d\ %H:%M:%S.%N 2>/dev/null | $BusyBox cut -c 1-21) $1" >> $LogFile
}
# 获取属性值方法
grep_prop(){
  # $1属性，$2文件
  $BusyBox sed -n "s/^$1=//p" $2 2>/dev/null | $BusyBox head -n 1
}
# 修改属性值方法
modify_prop(){
  # $1属性，$2属性值，$3文件
  local value="$2"
  [ "$value" == "empty" ] && value=""
  $BusyBox sed -i "s/^$1=.*/$1=$value/" $3
}
# 检查属性是否存在，结合-z使用
check_prop(){
  # $1属性，$2文件
  $BusyBox grep "^$1=" $2
}
# ------------------ 模块前缀标志位创建于删除
# 删除多个模块前缀标志位
removeModuleFlags(){
  # 遍历所有参数
  for param in $*; do
    # 依次查找并删除多个模块前缀标志位
    rm -rf `$BusyBox find $ModuleDir -path "$ModuleDir/$param*" -type f`
  done
}
# 删除单个模块前缀标志位
removeModuleFlag(){
  removeModuleFlags $1
}
# 创建单个模块前缀标志位文件
createModuleFlag(){
  # $1标志位前缀，$2标志位状态
  # 标志位前缀
  local flagPrefix="$1"
  # 当前需要的标志位
  local flag="$1$2"
  # 不存在当前需要的标志位进入
  if [ ! -f $ModuleDir/$flag ]; then
    # 删除已有模块前缀标志位
    removeModuleFlag $flagPrefix
    # 创建需要的模块前缀标志位
    touch $ModuleDir/$flag
  fi
}
# ------------------- 内部前缀标志位创建与删除
# 删除多个内部前缀标志位
removeInternalFlags(){
  # 遍历所有参数
  for param in $*; do
    # 依次查找并删除多个内部前缀标志位
    rm -rf `$BusyBox find $InternalFlagDir -path "$InternalFlagDir/$param*" -type f`
  done
}
# 删除单个内部前缀标志位
removeInternalFlag(){
  removeInternalFlags $1
}

# 创建单个内部前缀标志位
createInternalFlag(){
  # $1标志位前缀，$2标志位状态
  # 标志位前缀
  local flagPrefix="$1"
  # 当前需要的标志位
  local flag="$1$2"
  # 不存在当前需要的标志位进入
  if [ ! -f $InternalFlagDir/$flag ]; then
    # 删除已有内部前缀标志位
    removeInternalFlag $flagPrefix
    # 创建需要的内部前缀标志位
    touch $InternalFlagDir/$flag
  fi
}
# ------------------- 固定标志位创建与删除
# 删除多个固定标志位文件
removeConstantFlags(){
  for param in $*; do
    if [ -f $param ]; then
      # 删除固定标志位文件
      rm -rf $param
    fi
  done
}
# 删除单个固定标志位文件
removeConstantFlag(){
  removeConstantFlags $1
}
# 创建单个固定标志位文件
createConstantFlag(){
  # 不存在当前需要的标志位则创建
  if [ ! -f $1 ]; then
    # 创建需要的标志位文件
    touch $1
  fi
}
# ----------------------模块列表刷新方法
# 刷新模块列表的王者荣耀显示
refreshSgameDisplay(){
  $BusyBox sed -i "s/王者荣耀：.* 监听线程/王者荣耀：$1 监听线程/" $ModuleProp
}
# 刷新模块列表的监听线程显示
refreshMonitorDisplay(){
  $BusyBox sed -i "s/监听线程：.* 当前优化/监听线程：$1 当前优化/" $ModuleProp
}
# 刷新模块列表的当前优化显示
refreshCurrentOptimizeDisplay(){
  $BusyBox sed -i "s/当前优化：.* 当前模式/当前优化：$1 当前模式/" $ModuleProp
}
# 刷新模块列表的当前模式显示
refreshCurrentModeDisplay(){
  $BusyBox sed -i "s/当前模式：.* 倒计时/当前模式：$1 倒计时/" $ModuleProp
}
# 刷新模块列表的倒计时显示
refreshTimerDisplay(){
  $BusyBox sed -i "s/倒计时：.*/倒计时：$1/" $ModuleProp
}
# ---------------- 配置有效性检测及复原方法
# 复原默认日志配置
recoverLogConf(){
  if [ ! -f $LogConf ]; then
    touch $LogConf
  else
    $BusyBox sed -i '1,$d' $LogConf
  fi
  echo "# 保留第2行空间，自动生成日志大小限制是否生效的提示\n
      >># 可配置日志大小限制，单位MB，设置为0即不限制日志大小（无效配置将使用默认限制10MB）
      >># 修改限制，重启监听线程才会生效
      >>LogSizeLimit=10" >> $LogConf
  $BusyBox sed -i 's/.*>>//g' $LogConf
}
# 检查日志配置有效性
checkLogConf(){
  # 0返回值正常，1返回值异常且已复原默认配置
  # 日志配置0正常，1异常
  local state=0
  if [ -f $LogConf ]; then
    [ `$BusyBox grep -c "^LogSizeLimit=[0-9]*" $LogConf` == 0 ] && state=1
  else
     state=1
  fi
  if [ $state != 0 ]; then
    outputLog "--日志配置异常，复原默认配置--"
    recoverLogConf
    return 1
  fi
  return 0
}
# 复原默认倒计时配置
recoverTimerConf(){
  if [ ! -f $TimerConf ]; then
    touch $TimerConf
  else
    $BusyBox sed -i '1,$d' $TimerConf
  fi
  echo "# 保留第二行空间，自动生成倒计时配置是否生效的提示\n
      >># 无效倒计时配置不会生效（数字与时间单位有空格或其它字符，数字范围不符合要求）
      >># 总倒计时时间为0不启用倒计时
      >># 倒计时数据5秒刷新一次
      >># 最大天数30，最大小时24，最大分钟60，最大秒数60，监听线程运行时才会消耗倒计时，监听线程关闭自动暂停倒计时，未关闭倒计时，下次启动将继续完成倒计时
      >>TotalTime=0天0时0分0秒\n
      >># 以下属性倒计时配置有效情况下自动赋值，无效修改将恢复默认配置
      >># 倒计时总秒数时间（由TotalTime转换而来，查看作用）
      >>TotalSecondTime=
      >># 该次倒计时的开始时间（查看作用）
      >>StartTime=
      >># 由倒计时触发的监听线程关闭时间（查看作用）
      >>StopTime=
      >># 倒计时剩余的总时间（模块列表倒计时显示）
      >>RemainTime=
      >># 倒计时剩余的总秒数时间（用于继续倒计时）
      >>RemainSecondTime=" >> $TimerConf
  $BusyBox sed -i 's/.*>>//g' $TimerConf
}
# 检查倒计时配置有效性
checkTimerConf(){
  # 0返回值正常，1返回值异常且已复原默认配置
  # 倒计时配置0正常，1异常
  local state=0
  if [ -f $TimerConf ]; then
    if [ `$BusyBox grep -c "^TotalTime=[0-9][0-9]*天[0-9][0-9]*时[0-9][0-9]*分[0-9][0-9]*秒" $TimerConf` == 0 ]; then
      state=1
    else
      local TotalSecondTime=`check_prop "TotalSecondTime" $TimerConf`
      local StarTime=`check_prop "StartTime" $TimerConf`
      local StopTime=`check_prop "StopTime" $TimerConf`
      local RemainTime=`check_prop "RemainTime" $TimerConf`
      local RemainSecondTime=`check_prop "RemainSecondTime" $TimerConf`
      if [[ -z $TotalSecondTime || -z $StarTime || -z $StopTime || -z $RemainTime || -z $RemainSecondTime ]]; then
        state=1
      elif [[ ! -z `grep_prop "RemainSecondTime" $TimerConf` && `$BusyBox grep -c "^RemainSecondTime=[0-9][0-9]*" $TimerConf` == 0 ]]; then
        state=1
      fi
    fi
  else
    state=1
  fi
  if [ $state != 0 ]; then
    outputLog "--倒计时配置异常，复原默认配置--"
    recoverTimerConf
    return 1
  fi
  return 0
}
# 复原默认模块配置
recoverModuleProp(){
  if [ ! -f $ModuleProp ]; then
    touch $ModuleProp
  else
    $BusyBox sed -i '1,$d' $ModuleProp
  fi
  echo "id=$1
      >>name=$2
      >>version=$3
      >>versionCode=$4
      >>author=$5
      >>description=$6\n
      >>---版权所有，违者必究---" >> $ModuleProp
  $BusyBox sed -i 's/.*>>//g' $ModuleProp
}
# 检测模块Module.prop文件有效性
checkModuleProp(){
  # 0返回值正常，1返回值异常且已复原默认配置
  # Module.prop配置0正常，1异常
  local state=0
  # 模块id
  local id="sgame_pvp"
  # 模块名称
  local name="小男孩王者优化"
  # 模块版本
  local version="v4.0"
  # 模块版本号
  local versionCode=11
  # 模块作者
  local author="善良的小男孩"
  # 模块列表当前显示
  local description="王者荣耀：未监听 监听线程：已关闭 当前优化：模式未启用 当前模式：OpenGLES3（未启用） 倒计时：已关闭"
  if [ -f $ModuleProp ]; then
    local ID=`grep_prop "id" $ModuleProp`
    local NAME=`grep_prop "name" $ModuleProp`
    local VERSION=`grep_prop "version" $ModuleProp`
    local VERSIONCODE=`grep_prop "versionCode" $ModuleProp`
    local AUTHOR=`grep_prop "author" $ModuleProp`
    local DESCRIPTION=`grep_prop "description" $ModuleProp`
    # 判断模块列表是否缺失某项显示
    local CURRENTDISPLAY=`$BusyBox grep -c "description=王者荣耀：.* 监听线程：.* 当前优化：.* 当前模式：.* 倒计时：.*" $ModuleProp`
    local AUTHORITY=`$BusyBox grep -c "\-\-\-版权所有，违者必究\-\-\-" $ModuleProp`
    if [[ -z $ID || -z $NAME || -z $VERSION || -z $VERSIONCODE || -z $AUTHOR || -z $DESCRIPTION ]]; then
      state=1
    elif [[ $ID != $id || $NAME != $name || $VERSION != $version || $VERSIONCODE != $versionCode || $AUTHOR != $author ]]; then
      state=1
    elif [ $AUTHORITY == 0 ]; then
      state=1
    fi
    if [ $CURRENTDISPLAY != 0 ]; then
      description=$DESCRIPTION
    else
      state=1
    fi
  else
    state=1
  fi
  if [ $state != 0 ]; then
    outputLog "--模块配置异常，复原默认配置--"
    recoverModuleProp $id $name $version $versionCode $author "$description"
    return 1
  fi
  return 0
}
# 检查所有配置有效性
checkAllConf(){
  checkModuleProp
  checkTimerConf
  checkLogConf
}
# 清空倒计时配置
clearTimerConf(){
  if [ -f $TimerConf ]; then
    local empty="empty"
    # reset参数清空倒计时总时间配置
    [ ! -z $1 ] && [ $1 == "reset" ] && modify_prop "TotalTime" "0天0时0分0秒" $TimerConf
    modify_prop "TotalSecondTime" $empty $TimerConf
    modify_prop "StartTime" $empty $TimerConf
    modify_prop "StopTime" $empty $TimerConf
    modify_prop "RemainTime" $empty $TimerConf
    modify_prop "RemainSecondTime" $empty $TimerConf
  else
    recoverTimerConf
  fi
}
# 刷新倒计时配置
refreshTimerConf(){
  if [ -f $TimerConf ]; then
    local empty="empty"
    modify_prop "StartTime" "$1" $TimerConf
    modify_prop "StopTime" $empty $TimerConf
    modify_prop "RemainTime" $2 $TimerConf
    modify_prop "RemainSecondTime" $3 $TimerConf
  else
    recoverTimerConf
  fi
}
# 倒计时总秒数转化成固定格式显示
secondTimeToTime(){
  local time="0s"
  # $1秒数
  if [ $(($1 / 24 / 60 / 60)) -eq 0 ]; then
    if [ $(($1 / 60 / 60 % 24)) -eq 0 ];then
      if [ $(($1 / 60 % 60)) -eq 0 ]; then
        time="$(($1 % 60))s"
      else
        time="$(($1 / 60 % 60))m$(($1 % 60))s"
      fi
    else
      time="$(($1 / 60 / 60 % 24))h$(($1 / 60 % 60))m$(($1 % 60))s"
    fi
  else
    time="$(($1 / 24 / 60 / 60))d$(($1 / 60 / 60 % 24))h$(($1 / 60 % 60))m$(($1 % 60))s"
  fi
  echo "$time"
}
# 日志大小限制
logSizeLimit(){
  # 日志大小默认限制,单位MB
  local logSizeLimit=10
  if [ $1 == "empty" ]; then
    # 日志大小限制配置是否有效，0有效，1无效将使用默认限制
    local state=0
    if [ -f $LogConf ]; then
      # 获取日志大小限制
      local limit=`grep_prop "LogSizeLimit" $LogConf`
      if [ -z $limit ]; then
        state=1
      elif [ $limit -lt 0 ]; then
        state=1
      elif [ $limit -ge 0 ]; then
        logSizeLimit=$limit
        # 提示日志大小限制的配置有效
        if [ $logSizeLimit -eq 0 ]; then
          $BusyBox sed -i "2s/.*/--配置有效，不限制日志大小--/" $LogConf
          outputLog "--日志配置有效，不限制日志大小--"
        else
          $BusyBox sed -i "2s/.*/--配置有效（${logSizeLimit}MB=$(($logSizeLimit * 1024 * 1024))B）--/" $LogConf
          outputLog "--日志配置有效，日志大小限制${logSizeLimit}MB--"
        fi
      fi
    else
      state=1
    fi
    if [ $state == 1 ]; then
      # 提示日志大小限制的配置无效
      $BusyBox sed -i "2s/.*/--配置无效，已恢复默认配置--/" $LogConf
      # 复原默认日志配置
      recoverLogConf
      outputLog "--日志配置无效，使用默认限制(${logSizeLimit}MB)--"
    fi
  else
    logSizeLimit=$1
  fi
  # 限制日志文件大小，超过最大允许容量则删除日志文件，为0不限制
  if [ $logSizeLimit != 0 ] && [ `$BusyBox stat -c "%s" $LogFile` -gt $(($logSizeLimit * 1024 * 1024)) ]; then
    if [ -f $LogFile ]; then
      outputLog "--日志大小超过限制（${logSizeLimit}MB），删除日志--"
      rm -rf $LogFile
    fi
  fi
  echo $logSizeLimit
}