#!/system/bin/sh
# 内部脚本路径
InternalSh=INTERNAL_SH

if [ -f $InternalSh ]; then
  # 加载内部脚本
  . $InternalSh
  if [ -f $FlagMonitorRunning ]; then
    # 创建关闭监听线程标志位
    touch $FlagCloseMonitor
    echo -e "\e[32m执行成功！关闭监听线程！\e[0m"
  else
    echo -e "\e[33m监听线程未启动！无需关闭！\e[0m"
  fi
else
  echo -e "\e[31m执行失败！内部脚本缺失！\e[0m"
fi
