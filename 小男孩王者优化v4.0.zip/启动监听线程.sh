#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
# This script will be executed in late_start service mode
# MODDIR=${0%/*}

# 内部脚本路径
InternalSh=INTERNAL_SH

# --拷贝内部脚本全局变量过来，发布时注释，编写时取消注释用于代码提示--

# 模块安装路径
ModuleDir=MODULE_DIR
# 使用的busybox路径
BusyBox=BUSY_BOX
# 王者包名
Package=SGAME_PACKAGE
# 王者本地配置文件目录
SharedPrefs=SGAME_SHAREDPREFS
# 王者优化参数配置文件
File=SGAME_FILE

# 模块配置文件
ModuleProp=MODULE_PROP
# 内部标志位目录
InternalFlagDir=INTERNAL_FLAG_DIR
# 倒计时配置文件
TimerConf=TIMER_CONF
# 日志配置文件
LogConf=LOG_CONF
# 日志文件
LogFile=LOG_FILE

# 可用模式
ModeOpenGLES3="OpenGLES3"
ModeVulkan="Vulkan"
ModeVisitor="Visitor"

# 以下是标志位前缀---
# 王者标志位前缀
SgameFlagPrefix="王者"
# 监听线程标志位前缀
MonitorFlagPrefix="监听线程"
# 当前优化标志位前缀
CurrentOptimizeFlagPrefix="当前优化"
# 当前模式标志位前缀
CurrentModeFlagPrefix="当前模式"
# 切换模式标志位前缀，内部
ChangeModeFlagPrefix="切换模式"
# 倒计时标志位前缀
TimerFlagPrefix="倒计时"

# 以下是固定标志位---
# 切换模式标志位，内部
FlagChangeModeOpenGLES3="$InternalFlagDir/切换模式${ModeOpenGLES3}"
FlagChangeModeVulkan="$InternalFlagDir/切换模式${ModeVulkan}"
FlagChangeModeVisitor="$InternalFlagDir/切换模式${ModeVisitor}"
# 关闭监听线程标志位，内部
FlagCloseMonitor="$InternalFlagDir/关闭监听线程"
# 倒计时关闭监听线程标志位，内部
FlagTimerCloseMonitor="$InternalFlagDir/倒计时关闭监听线程"
# 已启用倒计时标志位，内部
FlagTimerApplied="$InternalFlagDir/已启用倒计时"
# 启用倒计时标志位，内部
FlagApplyTimer="$InternalFlagDir/启用倒计时"
# 暂停计时标志位，内部
FlagPauseTimer="$InternalFlagDir/暂停倒计时"
# 关闭倒计时标志位，内部
FlagCloseTimer="$InternalFlagDir/关闭倒计时"
# 已暂停倒计时标志位
FlagTimerPaused="$ModuleDir/已暂停倒计时"
# 已启用模式标志位
FlagOpenGLES3Applied="$ModuleDir/已启用${ModeOpenGLES3}模式"
FlagVulkanApplied="$ModuleDir/已启用${ModeVulkan}模式"
FlagVisitorApplied="$ModuleDir/已启用${ModeVisitor}模式"
# 停用模式标志位，内部
FlagStopOpenGLES3="$InternalFlagDir/停用${ModeOpenGLES3}模式"
FlagStopVulkan="$InternalFlagDir/停用${ModeVulkan}模式"
FlagStopVisitor="$InternalFlagDir/停用${ModeVisitor}模式"
# 当前模式标志位
FlagCurrentModeOpenGLES3="$ModuleDir/当前模式${ModeOpenGLES3}"
FlagCurrentModeVulkan="$ModuleDir/当前模式${ModeVulkan}"
FlagCurrentModeVisitor="$ModuleDir/当前模式${ModeVisitor}"
# 王者已关闭标志位
FlagSgameClosed="$ModuleDir/王者已关闭"
# 监听线程运行中标志位
FlagMonitorRunning="$ModuleDir/监听线程运行中"
# 启用自启标志位
FlagEnableBoot="$ModuleDir/已启用自启"

# 以下是模块列表各项目显示可用状态
# 王者荣耀
StateSgameDefault="未监听"
StateSgameClosed="已关闭"
StateSgameRunning="运行中"
# 监听线程
StateMonitorClosed="已关闭"
StateMonitorRunning="运行中"
# 当前优化
StateCurrentOptimizeDefault="模式未启用"
# 当前模式显示后缀
StateCurrentModeClosedSuffix="（未启用）"
StateCurrentModeRunningSuffix="（已启用）"
# 当前模式
StateCurrentModeDefault="$ModeOpenGLES3$StateCurrentModeClosedSuffix"
# 倒计时
StateTimerClosed="已关闭"
# 倒计时已暂停后缀
StateTimerPausedSuffix="（已暂停）"


# 使用存在的当前模式标志位，即最后一次使用过的模式，作为监听线程的开始模式
useLastMode(){
  if [ -f $FlagCurrentModeOpenGLES3 ]; then
    LastMode=$ModeOpenGLES3
  elif [ -f $FlagCurrentModeVulkan ]; then
    LastMode=$ModeVulkan
  elif [ -f $FlagCurrentModeVisitor ]; then
    LastMode=$ModeVisitor
  fi
  # 将保留的当前模式标志位赋值给初始模式，以实现使用最后一次使用过的模式
  CurrentMode=$LastMode
}
# 停用模式方法
stopMode(){
  case $1 in
    $ModeOpenGLES3)
    # 模式启用则才需要停用
    if [ -f $FlagOpenGLES3Applied ]; then
      # 创建停用OpenGLES3模式标志位
      createConstantFlag $FlagStopOpenGLES3
      # 防止持续检索模式状态
      local count=0
      # 阻塞，直到该模式停用
      while (true); do
        if [ ! -f $FlagOpenGLES3Applied ];then
          # 模式停止会自动删除该模式的停用标志位
          break
        # 模式还在运行可能是并发了，再次创建停用模式标志位以停用多个该模式线程
        else
          createConstantFlag $FlagStopOpenGLES3
        fi
        # 防止持续检索，休眠一秒
        sleep 1
        ((count++))
        # 5秒模式未停止是异常情况，跳出并关闭监听线程
        if [ $count -gt 5 ]; then
          # 删除停用OpenGLES3模式标志位
          removeConstantFlag $FlagStopOpenGLES3
          # 输出日志
          outputLog "--停用${CurrentMode}模式超时--"
          # 创建关闭监听线程标志位
          createConstantFlag $FlagCloseMonitor
          break
        fi
      done
    fi
    ;;
    $ModeVulkan)
    # 模式启用则才需要停用
    if [ -f $FlagVulkanApplied ]; then
      # 创建停用Vulkan模式标志位
      createConstantFlag $FlagStopVulkan
      # 防止持续检索模式状态
      local count=0
      # 阻塞，直到该模式停用
      while(true); do
        if [ ! -f $FlagVulkanApplied ];then
          # 模式停止会自动删除该模式的停用标志位
          break
        # 模式还在运行可能是并发了，再次创建停用模式标志位以停用多个该模式线程
        else
          createConstantFlag $FlagStopVulkan
        fi
        # 防止持续检索，休眠一秒
        sleep 1
        ((count++))
        # 5秒模式未停止是异常情况，跳出并关闭监听线程
        if [ $count -gt 5 ]; then
          # 删除停用Vulkan模式标志位
          removeConstantFlag $FlagStopVulkan
          # 输出日志
          outputLog "--停用${CurrentMode}模式超时--"
          # 创建关闭监听线程标志位
          createConstantFlag $FlagCloseMonitor
          break
        fi
      done
    fi
    ;;
    $ModeVisitor)
    # 直接删除已启用Visitor标志位即可，Visitor持续的当前优化检索（5秒一次）在其它模式不会启用
    removeConstantFlag $FlagVisitorApplied
    # 输出日志
    outputLog "已停用Visitor模式"
    ;;
  esac
}
# 模式切换方法
changeCurrentMode()
{
  # 记录上次模式，下个循环LastMode将与CurrentMode值相等，即只在模式切换的那次循环能触发切换模式对应的操作
  LastMode=$CurrentMode
  # 获取新模式，若同时切换当前模式外的另外多个模式，显然这里优先级别高到低顺序是OpenGLES3，Vulkan,Visitor
  if [ -f $FlagChangeModeOpenGLES3 ]; then
    CurrentMode=$ModeOpenGLES3
    removeInternalFlag $ChangeModeFlagPrefix
  elif [ -f $FlagChangeModeVulkan ]; then
    CurrentMode=$ModeVulkan
    removeInternalFlag $ChangeModeFlagPrefix
  elif [ -f $FlagChangeModeVisitor ]; then
    CurrentMode=$ModeVisitor
    removeInternalFlag $ChangeModeFlagPrefix
  fi
  # 创建当前模式标志位
  if [ $CurrentMode == $ModeOpenGLES3 ]; then
    createModuleFlag $CurrentModeFlagPrefix $ModeOpenGLES3
    # 其它模式，已启用VIsitor模式日志输出标志位重置
    VISITORAPPLIEDTIP=0
  elif [ $CurrentMode == $ModeVulkan ]; then
    createModuleFlag $CurrentModeFlagPrefix $ModeVulkan
    # 其它模式，已启用VIsitor模式日志输出标志位重置
    VISITORAPPLIEDTIP=0
  elif [ $CurrentMode == $ModeVisitor ]; then
    createModuleFlag $CurrentModeFlagPrefix $ModeVisitor
  fi
  # 当前模式改变则进入
  if [ $LastMode != $CurrentMode ]; then
    # 输出日志
    outputLog "切换模式中，上次模式：$LastMode，切换成：$CurrentMode"
    # 停用上次模式
    stopMode $LastMode
  fi
}
# 获取王者优化参数值方法
getParamValue(){
  echo `$BusyBox grep ".*<int name=\"$1\" value=\".*\" \/>.*" "$File" | $BusyBox sed "s/.*<int name=\"$1\" value=\"\(.*\)\" \/>.*/\1/"`
}
# 检索当前优化，此方法只在模式启用时被调用
checkCurrentOptimize()
{
  # $1当前模式
  # 优化类型
  local OptimizeType="未知"
  # 获取优化参数值
  local EnableGLES3=`getParamValue "EnableGLES3"`
  local EnableVulkan=`getParamValue "EnableVulkan"`
  local EnableMTR=`getParamValue "EnableMTR"`
  # Visitor模式输出优化参数值到日志
  if [ $1 == $ModeVisitor ]; then
    # 输出日志
    outputLog "EnableGLES3=$EnableGLES3 EnableVulkan=$EnableVulkan EnableMTR=$EnableMTR"
  fi
  # 优化类型判断
  if [ $EnableGLES3 == 3 ] && [ $EnableVulkan == 3 ]; then
    if [ $EnableMTR == 1 ]; then
      OptimizeType="O2T"
    else
      OptimizeType="O2F"
    fi
  fi
  if [ $EnableGLES3 == 2 ]; then
    if [ $EnableMTR == 1 ]; then
      OptimizeType="O3T"
    else
      OptimizeType="O3F"
    fi
  elif [ $EnableVulkan == 2 ]; then
    if [ $EnableMTR == 1 ]; then
      OptimizeType="VT"
    else
      OptimizeType="VF"
    fi
  fi
  # 创建当前优化标志位文件，未知类型当前优化标志位显示当前优化未知，不追加参数值
  createModuleFlag $CurrentOptimizeFlagPrefix $OptimizeType
  # 未知类型优化显示优化参数值
  if [ $OptimizeType == "未知" ]; then
    # 更新当前优化信息
    refreshCurrentOptimizeDisplay "${OptimizeType}(EnableGLES3=$EnableGLES3 EnableVulkan=$EnableVulkan EnableMTR=$EnableMTR)"
  else
    # 更新当前优化信息
    refreshCurrentOptimizeDisplay $OptimizeType
  fi
}
# 修改王者优化参数值方法
modifyParamValue(){
  $BusyBox sed -i "/.*<int name=\"$1\" value=\".*\" \/>.*/ s/.*<int name=\"$1\" value=\".*\" \/>.*/\ \ \ \ <int name=\"$1\" value=\"$2\" \/>/" "$File"
}
# 启用OpenGLES3优化
runOpenGLES3()
{
  {
    # 输出日志
    outputLog "已启用OpenGLES3模式"
    # 写入OpenGLES3优化参数值2
    modifyParamValue "EnableGLES3" 2
    if [ $? -eq 0 ]; then
      # 输出日志
      outputLog "EnableGLES3参数值 2 写入完毕"
    else
      # 输出日志
      outputLog "EnableGLES3参数值 2 写入失败"
    fi
    # 写入Vulkan优化参数值3
    modifyParamValue "EnableVulkan" 3
    # 模块列表的当前模式显示已启用
    refreshCurrentModeDisplay "$ModeOpenGLES3$StateCurrentModeRunningSuffix"
    # 更新模块当前优化信息
    checkCurrentOptimize $CurrentMode
    while (true); do
      # 创建已启用OpenGLES3模式标志位
      createConstantFlag $FlagOpenGLES3Applied
      # 检索到王者关闭标志位或停用模式则退出
      if [ -f $FlagSgameClosed ] || [ -f $FlagStopOpenGLES3 ]; then
        # 删除已启用OpenGLES3模式、停用OpenGLES3模式标志位
        removeConstantFlags $FlagOpenGLES3Applied $FlagStopOpenGLES3
        # 模块列表当前模式显示未启用
        refreshCurrentModeDisplay "$CurrentMode$StateCurrentModeClosedSuffix"
        # 输出日志
        outputLog "已停用OpenGLES3模式"
        break
      fi
      # 检索王者配置文件优化参数
      if [ `$BusyBox fgrep -c '<int name="EnableGLES3" value="2" />' "$File"` == 0 ]; then
        # 输出日志
        outputLog "EnableGLES3参数值被王者进程更改，纠正EnableGLES3参数值为 2 "
        # 写入OpenGLES3优化参数值 2
        modifyParamValue "EnableGLES3" 2
        if [ $? -eq 0 ]; then
          # 输出日志
          outputLog "EnableGLES3参数值纠正完毕"
        else
          # 输出日志
          outputLog "EnableGLES3参数值纠正失败"
        fi
      fi
    done
  } &
}
# 启用Vulkan优化
runVulkan()
{
  {
    # 输出日志
    outputLog "已启用Vulkan模式"
    # 写入Vulkan优化参数值 2
    modifyParamValue "EnableVulkan" 2
    if [ $? -eq 0 ]; then
      # 输出日志
      outputLog "EnableVulkan参数值 2 写入完毕"
    else
      # 输出日志
      outputLog "EnableVulkan参数值 2 写入失败"
    fi
    # 写入OpenGLES3优化参数值 3
    modifyParamValue "EnableGLES3" 3
    # 模块列表的当前模式显示已启用
    refreshCurrentModeDisplay "$ModeVulkan$StateCurrentModeRunningSuffix"
    # 更新模块当前优化信息
    checkCurrentOptimize $CurrentMode
    while (true); do
      # 创建已启用Vulkan模式标志位
      createConstantFlag $FlagVulkanApplied
      # 检索到王者关闭标志位或停用模式退出
      if [ -f $FlagSgameClosed ] || [ -f $FlagStopVulkan ]; then
        # 删除已启用Vulkan模式、停用Vulkan模式标志位
        removeConstantFlags $FlagVulkanApplied $FlagStopVulkan
        # 模块列表当前模式显示未启用
        refreshCurrentModeDisplay "$CurrentMode$StateCurrentModeClosedSuffix"
        # 输出日志
        outputLog "已停用Vulkan模式"
        break
      fi
      # 检索王者配置文件优化参数
      if [ `$BusyBox fgrep -c '<int name="EnableVulkan" value="2" />' "$File"` == 0 ]; then
        # 输出日志
        outputLog "EnableVulkan参数值被王者进程更改，纠正EnableVulkan参数值为 2 "
        # 写入Vulkan优化参数值 2
        modifyParamValue "EnableVulkan" 2
        if [ $? -eq 0 ]; then
          # 输出日志
          outputLog "EnableVulkan参数值纠正完毕"
          else
          # 输出日志
          outputLog "EnableVulkan参数值纠正失败"
        fi
      fi
    done
  } &
}
# 定时关闭停止监听线程方法
runCloseMonitorTimer()
{
  {
    # 获取倒计时剩余总秒数
    local RemainSecondTime=`grep_prop "RemainSecondTime" $TimerConf`
    # 倒计时时间为空退出倒计时
    if [ -z $RemainSecondTime ]; then
      # 删除已启用倒计时标志位
      removeConstantFlag $FlagTimerApplied
      return
    fi
    # 倒计时显示时间
    local RemainTime=`secondTimeToTime $RemainSecondTime`
    # 获取此次倒计时开始时间，单位秒
    local StartSecondTime=`$BusyBox date +%s`
    # 此次倒计时开始时间的格式时间
    local StartTime=`$BusyBox date -d @$StartSecondTime +%y-%m-%d\ %H:%M:%S`
    # 对比时间戳
    local TempSecondTime=$StartSecondTime
    # RemainTime中只有秒数不用显示总秒数
    if [ `echo $RemainTime | $BusyBox grep -c "m"` == 0 ]; then
      # 输出志
      outputLog "开始倒计时，开始时间：$StartTime，倒计时：$RemainTime"
    else
      # 输出日志
      outputLog "开始倒计时，开始时间：$StartTime，倒计时：$RemainTime，总秒数：${RemainSecondTime}"
    fi
    # 倒计时状态标志位，0倒计时运行中，1倒计时完毕，2关闭倒计时,3暂停倒计时
    local State=0
    while (true); do
      if [ -f $FlagCloseTimer ]; then
        rm -rf $FlagCloseTimer
        # 关闭倒计时
        State=2
      fi
      if [ -f $FlagPauseTimer ]; then
        rm -rf $FlagPauseTimer
        # 暂停倒计时
        State=3
      fi
      # 倒计时运行中，刷新数据显示
      if [ $State  != 2 ]; then
        # 创建已启用倒计时标志位
        createConstantFlag $FlagTimerApplied
        # 获取倒计时剩余总秒数
        RemainSecondTime=`grep_prop "RemainSecondTime" $TimerConf`
        # 倒计时刚好完毕，很可能倒计时剩余总秒数为负数，但倒计时配置中的仅供查看时间应显示为0
        if [ $RemainSecondTime -le 0 ]; then
          RemainSecondTime=0
          State=1
        fi
        # 剩余倒计时格式化显示
        RemainTime=`secondTimeToTime $RemainSecondTime`
        # 创建倒计时标志位
        createModuleFlag $TimerFlagPrefix $RemainTime
        # 刷新模块列表的倒计时显示
        refreshTimerDisplay $RemainTime
        # 刷新倒计时配置
        refreshTimerConf "$StartTime" $RemainTime $RemainSecondTime
      fi
      # 倒计时完毕，退出计时线程
      if [ $State == 1 ]; then
        # 删除已启用倒计时标志位
        removeConstantFlag $FlagTimerApplied
        # 删除倒计时标志位文件
        removeModuleFlag $TimerFlagPrefix
        # 创建倒计时关闭监听线程标志位
        createConstantFlag $FlagTimerCloseMonitor
        # 模块列表显示倒计时已关闭
        refreshTimerDisplay $StateTimerClosed
        # 输出日志
        outputLog "倒计时完毕，即将关闭监听线程"
        break
      fi
      # 关闭倒计时，退出计时线程
      if [ $State == 2 ]; then
        # 删除已启用倒计时标志位
        removeConstantFlag $FlagTimerApplied
        # 删除倒计时标志位文件
        removeModuleFlag $TimerFlagPrefix
        # 清空倒计时配置
        clearTimerConf
        # 模块列表显示倒计时已关闭
        refreshTimerDisplay $StateTimerClosed
        # 输出日志
        outputLog "已关闭倒计时"
        break
      fi
      # 暂停倒计时,退出计时线程
      if [ $State == 3 ]; then
        # 删除倒计时标志位文件
        removeModuleFlag $TimerFlagPrefix
        # 删除已启用倒计时标志位
        removeConstantFlag $FlagTimerApplied
        # 创建倒计时已暂停标志位
        createConstantFlag $FlagTimerPaused
        # 模块列表倒计时显示剩余时间及已暂停状态
        refreshTimerDisplay "$RemainTime$StateTimerPausedSuffix"
        # 输出日志
        outputLog "倒计时已暂停"
        break
      fi
      # 计时线程休眠5秒
      local count=0
      while (true); do
        # 计时线程已休眠5秒，继续计时操作
        if [ $count -ge 5 ]; then
          break
        fi
        # 检索关闭倒计时、暂停倒计时
        if [[ -f $FlagCloseTimer || -f $FlagPauseTimer ]]; then
          break
        fi
        # 每秒检索一次倒计时事务
        sleep 1
        ((count++))
      done
      # 倒计时运行中，消耗倒计时剩余总秒数
      if [ $State == 0 ]; then
        # 获取当前时间戳，单位秒
        local CurrentSecondTime=`$BusyBox date +%s`
        # 当前时间戳对比TempSecondTime，即不断计算监听线程运行秒数时间，从而消耗倒计时时间
        local ElapseSecondTime=$(($CurrentSecondTime - $TempSecondTime))
        # 用CurrentSecondTime赋值给TempSecondTime作为下次对比对象，这样下次获取新的CurrentSecondTime从而计算监听线程又运行了多少秒
        TempSecondTime=$CurrentSecondTime
        # 倒计时剩余总秒数减去该次计算出的监听线程已运行的秒数作为新的倒计时剩余总秒数
        RemainSecondTime=$(($RemainSecondTime - $ElapseSecondTime))
        # 刷新倒计时内部配置中的RemainSecondTime值
        modify_prop "RemainSecondTime" $RemainSecondTime $TimerConf
      fi
    done
  } &
}
# 启动监听线程
runProcessMonitor()
{
  {
    echo -e "\e[32m执行成功！启动监听线程！\e[0m"
    # 输出日志
    outputLog "监听线程运行中"
    # 指示王者1启动与0关闭
    SGAMECLOSED=0
    # 指示模式是否允许运行，0允许，1模式切换才允许，2不允许
    MODERUNABLE=0
    # 是否提示当前模式未启用，0提示，1不提示
    MODETIP=0
    # 已启用Visitor模式日志输出控制，0未曾输出，1已输出过
    VISITORAPPLIEDTIP=0
    # 日志大小限制
    LogSizeLimit="empty"
    # 初始模式，默认OpenGLES3模式
    CurrentMode=$ModeOpenGLES3
    # 最后一次使用的模式,没有则默认OpenGLES3模式
    LastMode=$ModeOpenGLES3
    # 使用遗留的当前模式标志位作为初始模式
    useLastMode
    # 监听线程主体代码
    while (true); do
      # 创建监听线程运行中标志位
      createModuleFlag $MonitorFlagPrefix $StateMonitorRunning
      # 模块列表监听线程显示运行中
      refreshMonitorDisplay $StateMonitorRunning
      # 日志大小限制，仅解析一次日志限制，更改限制，需重启监听线程
      LogSizeLimit=`logSizeLimit "$LogSizeLimit"`
      # 切换模式
      changeCurrentMode
      # 王者配置文件不存在、关闭监听线程标志位存在、倒计时关闭监听线程标志位存在时进入
      if [ ! -f $File ] || [ -f $FlagCloseMonitor ] || [ -f $FlagTimerCloseMonitor ]; then
        # 删除关闭监听线程标志位
        removeConstantFlag $FlagCloseMonitor
        # 删除王者、监听线程、当前优化前缀标志位，保留当前模式标志位，用作下次监听线程启动的开始模式
        removeModuleFlags $SgameFlagPrefix $MonitorFlagPrefix $CurrentOptimizeFlagPrefix
        # 模块列表王者荣耀显示未监听
        refreshSgameDisplay $StateSgameDefault
        # 模块列表监听线程显示已关闭
        refreshMonitorDisplay $StateMonitorClosed
        # 模块列表当前优化显示模式未启用
        refreshCurrentOptimizeDisplay $StateCurrentOptimizeDefault
        # 模块列表当前模式显示未启用
        refreshCurrentModeDisplay "$CurrentMode$StateCurrentModeClosedSuffix"
        # 监听线程退出，停止模式
        stopMode $CurrentMode
        # 监听线程退出，若已启用倒计时则暂停倒计时，模块倒计时显示由计时线程刷新
        if [ -f $FlagTimerApplied ]; then
          createConstantFlag $FlagPauseTimer
        else
          refreshTimerDisplay $StateTimerClosed
        fi
        # 倒计时关闭监听线程进入
        if [ -f $FlagTimerCloseMonitor ]; then
          # 刷新倒计时配置中的StopTime，即倒计时关闭监听线程时间
          modify_prop "StopTime" "`$BusyBox date  +%y-%m-%d\ %H:%M:%S`" $TimerConf
          # 删除倒计时关闭监听线程标志位文件
          rm -rf $FlagTimerCloseMonitor
        fi
        # 输出日志
        outputLog "监听线程已关闭"
        break
      fi
      # 查询王者包名进程数
      SGAME_PID_NUM=`$BusyBox ps -o args | $BusyBox grep -v "grep" | $BusyBox grep -c $Package`
      # 王者进程数 0 时进入
      if [ $SGAME_PID_NUM == 0 ]; then
        # 王者关闭瞬间进入（非持续关闭状态进入）
        if [ $SGAMECLOSED != 0 ]; then
          # 指示王者关闭，赋值0
          SGAMECLOSED=0
          # 王者关闭，赋值0，指示下次王者进程可直接启用模式
          MODERUNABLE=0
          # 输出日志
          outputLog "王者正式服已关闭"
          # 王者退出，删除已启用Visitor模式标志位
          if [ $CurrentMode == $ModeVisitor ];then
            # 删除已启用Visitor模式标志位
            removeConstantFlag $FlagVisitorApplied
            # 输出日志
            outputLog "已停用Visitor模式"
          fi
        fi
        # 创建王者已关闭标志位
        createModuleFlag $SgameFlagPrefix $StateSgameClosed
        # 模块列表王者荣耀显示已关闭
        refreshSgameDisplay $StateSgameClosed
        # 删除当前优化标志位
        removeModuleFlag $CurrentOptimizeFlagPrefix
        # 模块列表当前优化显示模式未启用
        refreshCurrentOptimizeDisplay $StateCurrentOptimizeDefault
        # 模块列当前模式显示未启用
        refreshCurrentModeDisplay "$CurrentMode$StateCurrentModeClosedSuffix"
        # 未提示过当前模式未启用或模式切换则进入
        if [ $MODETIP == 0 ] || [ $LastMode != $CurrentMode ]; then
          # 此当前模式已提示过，赋值1
          MODETIP=1
          # 输出日志
          outputLog "王者正式服未运行，当前${CurrentMode}模式未启用"
        fi
      # 王者进程数非 0 时进入
      else
        # 创建王者运行中标志位
        createModuleFlag $SgameFlagPrefix $StateSgameRunning
        # 模块列表王者荣耀显示运行中
        refreshSgameDisplay $StateSgameRunning
        # 王者启动瞬间进入（非运行时）
        if [ $SGAMECLOSED == 0 ]; then
          # 赋值王者启动
          SGAMECLOSED=1
          # 先启动游戏再启动监听线程的情况无需提示，赋值1
          MODETIP=1
          # 输出日志
          outputLog "王者正式服运行中"
          # 王者运行后，启用模式前，检索优化参数是否存在
          EXIST1=`$BusyBox grep '.*<int name="EnableGLES3" value=".*" \/>.*' "$File"`
          EXIST2=`$BusyBox grep '.*<int name="EnableVulkan" value=".*" \/>.*' "$File"`
          if [[ -z $EXIST1 || -z $EXIST2 ]]; then
            # 输出日志
            outputLog "优化参数不存在，无法启用模式"
            # 未通过检测赋值2
            MODERUNABLE=2
          else
            # 输出日志
            outputLog "优化参数存在，准备启用模式"
          fi
        fi
        # 此次王者进程未启用过模式或模式切换时进入
        if [ $MODERUNABLE == 0 ] || [ $CurrentMode != $LastMode ]; then
          # 通过优化参数存在检测则进入
          if [ $MODERUNABLE != 2 ]; then
            # 此次王者进程启用过模式，赋值1
            MODERUNABLE=1
            case $CurrentMode in
              $ModeOpenGLES3)
              runOpenGLES3
              ;;
              $ModeVulkan)
              runVulkan
              ;;
            esac
          fi
        fi
        # Visitor模式并非优化模式，用于查看优化参数值，持续检索当前优化类型（5秒一次）
        if [ $CurrentMode == $ModeVisitor ];then
          # 创建已启用Visitor模式标志位文件
          createConstantFlag $FlagVisitorApplied
          # 已启用VIsitor模式日志输出过赋值1
          if [ $VISITORAPPLIEDTIP == 0 ]; then
            outputLog "已启用Visitor模式"
            VISITORAPPLIEDTIP=1
          fi
          # 模块列表的当前模式显示已启用，已启用日志在王者启动时输出，避免重复输出
          refreshCurrentModeDisplay "$CurrentMode$StateCurrentModeRunningSuffix"
        fi
        # 更新模块当前优化信息，5秒刷新一次
        checkCurrentOptimize $CurrentMode
      fi
      # 事务操作，包含关闭监听线程、模式切换、倒计时操作等
      # 事务操作每1秒监听1次共5次，即监听线程主体休眠了5秒，此操作为更快响应事务操作，无需再等待5秒
      count=0
      while (true); do
        # 监听线程主体已经休眠了5秒，跳出执行监听线程主体
        if [ $count -ge 5 ]; then
          break;
        fi
        # 判断是否有新事务，有则跳出，以便监听线程立即执行新事务
        if [[ -f $FlagCloseMonitor || -f $FlagChangeModeOpenGLES3 || -f $FlagChangeModeVulkan || -f $FlagChangeModeVisitor || -f $FlagTimerCloseMonitor ]]; then
          break
        fi
        # 启用倒计时或已暂停倒计时，则开启计时线程
        if [[ -f $FlagApplyTimer || -f $FlagTimerPaused ]]; then
          removeConstantFlags $FlagApplyTimer $FlagTimerPaused
          if [ ! -f $FlagTimerApplied ]; then
            # 创建已启用倒计时标志位，虽然计时线程未运行，防止并发
            createConstantFlag $FlagTimerApplied
            runCloseMonitorTimer
          fi
        fi
        # 没有新事务休眠1秒，下1秒继续检索是否有新事务
        sleep 1
        # 指示监听线程主体已休眠秒数
        ((count++))
      done
    done
  } &
}

if [ -f $InternalSh ]; then
  # 加载内部脚本
  . $InternalSh
  if [ -f $File ]; then
    if [ ! -f $FlagMonitorRunning ]; then
      # 检测所有配置有效性
      checkAllConf
      # 启动监听线程
      runProcessMonitor
    else
      echo -e "\e[33m监听线程已启动！无需再次启动！\e[0m"
    fi
  else
    echo -e "\e[31m执行失败！王者正式服配置文件不存在！不能启动监听线程！\e[0m"
  fi
else
  echo -e "\e[31m执行失败！内部脚本缺失！\e[0m"
fi