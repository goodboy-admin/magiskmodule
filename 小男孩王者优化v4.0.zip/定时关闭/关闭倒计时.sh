#!/system/bin/sh
# 内部脚本路径
InternalSh=INTERNAL_SH

if [ -f $InternalSh ]; then
  # 加载内部脚本
  . $InternalSh
  # 0未启用倒计时，1已启用倒计时，2已暂停倒计时
  state=0
  # 判断是否已启用倒计时
  if [ -f $FlagTimerApplied ]; then
    # 创建关闭倒计时标志位
    touch $FlagCloseTimer
    state=1
  # 若已暂停倒计时则删除已暂停倒计时标志位，并清空倒计时配置
  elif [  -f $FlagTimerPaused ]; then
    # 删除已暂停倒计时标志位
    rm -rf $FlagTimerPaused
    # 清空倒计时配置
    clearTimerConf
    state=2
  fi
  if [ $state == 0 ]; then
    echo -e "\e[33m未启用倒计时！无需关闭！\e[0m"
  elif [ $state == 1 ]; then
    echo -e "\e[32m执行成功！关闭倒计时！\e[0m"
  elif [ $state == 2 ]; then
    echo -e "\e[32m执行成功！不再继续未完成的倒计时！\e[0m"
  fi
else
  echo -e "\e[31m执行失败！内部脚本缺失！\e[0m"
fi