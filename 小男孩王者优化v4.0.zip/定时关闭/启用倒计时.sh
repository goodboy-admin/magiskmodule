#!/system/bin/sh
# 内部脚本路径
InternalSh=INTERNAL_SH

# 解析倒计时配置
resolveTimerConf()
{
  if [ -f $FlagMonitorRunning ]; then
    if [ ! -f $FlagTimerApplied ] && [ ! -f $FlagApplyTimer ]; then
      # 提取倒计时配置中的时间值
      day=`$BusyBox grep '^TotalTime=.*' $TimerConf | $BusyBox sed 's/TotalTime=\(.*\)天.*/\1/'`
      hour=`$BusyBox grep '^TotalTime=.*' $TimerConf | $BusyBox sed 's/TotalTime=.*天\(.*\)时.*/\1/'`
      minute=`$BusyBox grep '^TotalTime=.*' $TimerConf | $BusyBox sed 's/TotalTime=.*天.*时\(.*\)分.*/\1/'`
      second=`$BusyBox grep '^TotalTime=.*' $TimerConf | $BusyBox sed 's/TotalTime=.*天.*时.*分\(.*\)秒.*/\1/'`
      # 倒计时配置有效性标志，0有效，1无效
      valuebale=0
      if [[ -z $day || -z $hour || -z $minute || -z $second ]]; then
        valuebale=1
      else
        # 天时间值范围判断
        if ! [ $day -ge 0 -a $day -le 30 ]; then
          valuebale=1
        fi
        # 时时间值范围判断
        if ! [ $hour -ge 0 -a $hour -le 24 ]; then
          valuebale=1
        fi
        # 分时间值范围判断
        if ! [ $minute -ge 0 -a $minute -le 60 ]; then
          valuebale=1
        fi
        # 秒时间值范围判断
        if ! [ $second -ge 0 -a $second -le 60 ]; then
          valuebale=1
        fi
      fi
      # 倒计时配置无效
      if [ $valuebale == 1 ]; then
        # 倒计时配置无效，清空倒计时配置 reset
        clearTimerConf "reset"
        # 模块列表倒计时显示已关闭
        refreshTimerDisplay $StateTimerClosed
        # 倒计时配置无效提示
        $BusyBox sed -i "2s/.*/--配置无效，已恢复默认配置--/" $TimerConf
        echo -e "\e[31m执行失败！倒计时配置无效！\e[0m"
      else
        # 倒计总时间转化成倒计总秒数
        TotalSecondTime=$((0 + $day * 24 * 60 * 60 + $hour * 60 * 60 + $minute * 60 + $second))
        # 倒计时总时间为零
        if [ $TotalSecondTime == 0 ]; then
          # 模块列表倒计时显示已关闭
          refreshTimerDisplay $StateTimerClosed
          # 倒计时为0提示
          $BusyBox sed -i "2s/.*/--倒计时总时间为0！不启用倒计时！--/" $TimerConf
          echo -e "\e[33m倒计时总秒数为0！不启用倒计时！\e[0m"
        # 倒计时有效
        else
          # 倒计时有效，清空倒计时用于查看的数据
          clearTimerConf
          # 倒计时总秒数转为固定格式时间
          TotalTime=`secondTimeToTime $TotalSecondTime`
          # 写入TotalSecondTime倒计时总秒数至倒计时配置
          modify_prop "TotalSecondTime" $TotalSecondTime $TimerConf
          # 转换TotalSecondTime倒计时总秒数至倒计时配置中的RemainTime
          modify_prop "RemainTime" `secondTimeToTime "$TotalSecondTime"` $TimerConf
          # 写入TotalSecondTime倒计时总秒数至倒计时配置中的RemainSecondTime
          modify_prop "RemainSecondTime" $TotalSecondTime $TimerConf
          # 倒计时配置有效提示
          $BusyBox sed -i "2s/.*/--配置有效，已刷新TotalSecondTime--/" $TimerConf
          # 模块列表倒计时显示已关闭，倒计时真正启用后会刷新模块列表倒计时，这里先重置显示
          refreshTimerDisplay $StateTimerClosed
          # 创建启用倒计时标志位
          touch $FlagApplyTimer
          echo -e "\e[32m执行成功！倒计时\e[0m\e[33m ${TotalTime} \e[0m\e[32m！\e[0m"
        fi
      fi
    else
      echo -e "\e[33m当前已启用倒计时！关闭倒计时或倒计时完毕后才可再次启用！\e[0m"
    fi
  else
    echo -e "\e[31m执行失败！监听线程未启动！\e[0m"
  fi
}

if [ -f $InternalSh ]; then
  # 加载内部脚本
  . $InternalSh
  # 倒计时配置正常则可继续解析倒计时配置
  if checkTimerConf; then
    resolveTimerConf
  else
    echo -e "\e[31m执行失败！倒计时配置异常，已恢复默认配置！请重新配置再启用！\e[0m"
  fi
else
  echo -e "\e[31m执行失败！内部脚本缺失！\e[0m"
fi