#!/system/bin/sh
# 内部脚本路径
InternalSh=INTERNAL_SH

if [ -f $InternalSh ]; then
  # 加载内部脚本
  . $InternalSh
  # 删除日志
  if [ -f $LogFile ]; then
    rm -rf $LogFile
    echo -e "\e[32m执行成功！删除日志！\e[0m"
  else
    echo -e "\e[33m没有日志！无需删除！\e[0m"
  fi
else
  echo -e "\e[31m执行失败！内部脚本缺失！\e[0m"
fi