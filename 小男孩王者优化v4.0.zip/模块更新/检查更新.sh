#!/system/bin/sh

# 内部脚本路径
InternalSh=INTERNAL_SH

runUpdate(){
  {
    # 最新版模块信息
    updateInfoUrl="http://free44858.hosthd1.ldvps.com/sgame_pvp/updateInfo.txt"
    # cache目录
    cacheDir="$InternalDir/cache"
    mkdir -p $cacheDir
    # 新版本下载目录
    downloadDir="$ModuleUpdateDir/download"
    mkdir -p $downloadDir
    # 获取模块信息
    id=`grep_prop "id" $ModuleProp`
    name=`grep_prop "name" $ModuleProp`
    author=`grep_prop "author" $ModuleProp`
    versionCode=`grep_prop "versionCode" $ModuleProp`
    echo -e "\e[32m获取最新版本信息中...\e[0m"
    # 获取最新版本模块信息
    $BusyBox wget $updateInfoUrl -O $cacheDir/downloading_updateInfo -o $cacheDir/updateInfo.log -q
    count=0
    while (true); do
      if [ $count -gt 10 ]; then
        echo -e "\e[33m检查更新超时！请重新检查更新！\e[0m"
        return
      fi
      if [[ -f $cacheDir/updateInfo.log && `$BusyBox grep -c "100%" $cacheDir/updateInfo.log` -gt 0 ]]; then
        $BusyBox mv $cacheDir/downloading_updateInfo $cacheDir/updateInfo.txt
        ID=`grep_prop "id" $cacheDir/updateInfo.txt`
        NAME=`grep_prop "name" $cacheDir/updateInfo.txt`
        AUTHOR=`grep_prop "author" $cacheDir/updateInfo.txt`
        VERSION=`grep_prop "version" $cacheDir/updateInfo.txt`
        VERSIONCODE=`grep_prop "versionCode" $cacheDir/updateInfo.txt`
        RESNAME=`grep_prop "resName" $cacheDir/updateInfo.txt`
        RESURL=`grep_prop "resUrl" $cacheDir/updateInfo.txt`
        OVERTIME=`grep_prop "overTime" $cacheDir/updateInfo.txt`
        UPDATEDESCRIPTION=`grep_prop "updateDescription" $cacheDir/updateInfo.txt`
        rm -rf $cacheDir/updateInfo.log $cacheDir/updateInfo.txt
        break
      fi
      sleep 1
      ((count++))
    done
    # 对比版本信息
    if [[ $id != $ID || $name != $NAME || $author != $AUTHOR ]]; then
      echo -e "\e[31m当前版本与最新版本模块信息不匹配，无法更新！\e[0m"
      return
    elif [ $versionCode -lt $VERSIONCODE ]; then
      echo -e "\e[32m检测到新版本${VERSION}！正在下载...\e[0m"
      $BusyBox wget $RESURL -O $downloadDir/downloading_$RESNAME -o $cacheDir/download.log -q
      count=0
      while (true); do
        if [ $count -gt $OVERTIME ]; then
          echo -e "\e[33新版本下载超时！请重新检查更新或直接下载最新版！\e[0m"
          break
        fi
        if [[ -f $cacheDir/download.log && `$BusyBox grep -c "100%" $cacheDir/download.log` -gt 0 ]]; then
          $BusyBox mv $downloadDir/downloading_$RESNAME $downloadDir/$RESNAME
          rm -rf $cacheDir/download.log
          echo "$UPDATEDESCRIPTION" > $downloadDir/${VERSION}更新内容.txt
          echo -e "\e[32m下载完成！\e[0m"
          break
        fi
        sleep 1
        ((count++))
      done
    elif [ $versionCode -ge $VERSIONCODE ]; then
      echo -e "\e[33m已是最新版本！无需更新！\e[0m"
    fi
  } &
}

if [ -f $InternalSh ];then
  # 加载内部脚本
  . $InternalSh
  # 检查模块配置有效性
  echo -e "\e[32m检索模块配置中...\e[0m"
  if checkModuleProp; then
    echo -e "\e[32m模块配置正常！\e[0m"
  else
    echo -e "\e[33m模块配置异常！已复原默认模块配置！\e[0m"
  fi
  echo -e "\e[32m检查更新中...\e[0m"
  runUpdate
else
  echo -e "\e[31m执行失败！内部脚本缺失！\e[0m"
fi

