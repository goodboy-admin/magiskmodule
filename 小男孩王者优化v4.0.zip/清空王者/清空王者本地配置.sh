#!/system/bin/sh
# 清空王者本地配置
# 因使用旧机制版本导致王者出现不正常现象，如更改王者画面质量，下次重启游戏画面质量未有变动及登录超时、闪退等
# 执行此脚本后重启游戏
# 仍然未能解决问题，清空王者应用缓存后重启游戏
# 还是不能解决问题，清除游戏应用全部数据可恢复正常

# 获取王者正式服本地配置目录路径
SharedPrefs=SGAME_SHAREDPREFS

# 删除王者正式服本地配置文件夹及配置文件
if [ -d $SharedPrefs ]; then
  rm -rf $SharedPrefs
  if [ $? -eq 0 ];then
    echo -e "\e[32m执行成功！王者正式服本地配置已清空！\e[0m"
  else
    echo -e "\e[31m执行失败！王者正式服本地配置未能清空！\e[0m"
  fi
else
  echo -e "\e[33m王者正式服本地配置已清空！无需再次清空！\e[0m"
fi