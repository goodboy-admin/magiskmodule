#!/system/bin/sh
# 内部脚本路径
InternalSh=INTERNAL_SH

if [ -f $InternalSh ]; then
  # 加载内部脚本
  . $InternalSh
  if [ ! -f $FlagEnableBoot ]; then
    touch $FlagEnableBoot
    echo -e "\e[32m执行成功！启用开机自启！\e[0m"
  else
    echo -e "\e[33m已启用开机自启！无需再次启用！\e[0m"
  fi
else
  echo -e "\e[31m执行失败！内部脚本缺失！\e[0m"
fi